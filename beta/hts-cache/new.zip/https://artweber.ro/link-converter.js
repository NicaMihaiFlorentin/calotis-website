<!DOCTYPE html>
<html lang="ro">
<head>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4084293060742207"
     crossorigin="anonymous"></script>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<meta charset="utf-8">
<title>artweber - Aici puteți descărca gratuit șabloane și module premium pentru diferite CMS!</title>
<meta name="description" content="artweber - Aici puteti descarca gratuit sabloane si module premium pentru diferite CMS!">
<meta name="keywords" content="teme, șabloane, gratuit, cms, comerț electronic, wordpress, joomla, drupal, html, psd, uCoz, dle, cms, hacks dle, dle modules, dle cms, cms joomla, dle modules, ipb forum, ipb download, ipb hooks, scripturi pentru ucoz, șabloane gratuite pentru uCoz, teme wordpress gratuite, descărcare vbulletin, șabloane vbulletin, extensii joomla, șabloane site, dezvoltare site web, design site web,indexuri forum,index forum,indexuri gaming, teme gaming,psduri,psd bannere">
<meta name="generator" content="DataLife Engine (http://dle-news.ru)">
<link rel="search" type="application/opensearchdescription+xml" href="https://artweber.ro/index.php?do=opensearch" title="artweber - Aici puteți descărca gratuit șabloane și module premium pentru diferite CMS!">
<link rel="alternate" type="application/rss+xml" title="artweber - Aici puteți descărca gratuit șabloane și module premium pentru diferite CMS!" href="https://artweber.ro/rss.xml">
<link rel="shortcut icon" href="/templates/BOOTBLOG/images/batch-script--v1.png">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500&display=swap" rel="stylesheet">
<link href="/templates/BOOTBLOG/css/materialdesignicons.min.css" rel="stylesheet">
<link class="js-stylesheet" href="/templates/BOOTBLOG/css/light.css" rel="stylesheet">
<link href="/templates/BOOTBLOG/css/engine.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="/templates/BOOTBLOG/css/avatars.css">
    <meta name="google-site-verification" content="2m0rc3oIU6TE9CsFGxisLd_0AkL3rby-QBjarSonrkY" />
    
   <meta name="mailru-domain" content="gV5MwN2wGnx2DwYx" />
    
</head>

<script type="text/javascript">
var adfly_id = 12665591;
var adfly_advert = 'int';
var adfly_protocol = 'https';
var adfly_domain = 'adf.ly';
var domains = ['yadi.sk','disk.yandex.md','d1.pandashare.me','d2.pandashare.me','mir.cr','mega.nz','drive.google.com','themeforest.net','codecanyon.net']
</script>
<script src="https://cdn.adf.ly/js/link-converter.js"></script>



<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

   ym(54882298, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true
   });
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/54882298" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->

<body data-theme="default" data-layout="fluid" data-sidebar-position="left" data-sidebar-behavior="sticky">

             <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function () {
			$('#cssmenu li.has-sub > a').on('click', function(){
				$(this).removeAttr('href');
				var element = $(this).parent('li');
				if (element.hasClass('open')) {
					element.removeClass('open');
					element.find('li').removeClass('open');
					element.find('ul').slideUp();
				}
				else {
					element.addClass('open');
					element.children('ul').slideDown();
					element.siblings('li').children('ul').slideUp();
					element.siblings('li').removeClass('open');
					element.siblings('li').find('li').removeClass('open');
					element.siblings('li').find('ul').slideUp();
				}
			});

			$('#cssmenu>ul>li.has-sub>a').append('<span class="holder"></span>');
        });
    </script>

<div class="wrapper">

<nav id="sidebar" class="sidebar">
<div class="sidebar-content js-simplebar">

<a class="sidebar-brand" href="/"><i class="mdi mdi-xml"></i><span class="alogn-middle mr-3">artweber</span></a>

<ul class="sidebar-nav">
<li class="sidebar-header">Categorii</li>
	<div id='cssmenu'>
		<ul>
		   <li class='has-sub'><a href='#'><span>WordPress</span></a>
			  <ul>
				 <li><a href='/wordpress/'><span>Totul pentru WordPress</span></a></li>
				 <li><a href='/wordpress/wp-themes/'><span>Teme / Șabloane <span class="badge badge-sidebar-primary"> 37 </span></span></a></li>
				 <li><a href='/wordpress/wp-plugins/'><span>Plugin-uri </span> <span class="badge badge-sidebar-primary"> 48 </span></a></li>
			  </ul>
		   </li>
		   <li class='has-sub'><a href='#'><span>WooCommerce</span></a>
			  <ul>
				 <li><a href='/woocommerce/'><span>Totul pentru WooCommerce</span></a></li>
				 <li><a href='/woocommerce/woocommerce-themes/'><span>Teme / Șabloane <span class="badge badge-sidebar-primary"> 7 </span></span></a></li>
				 <li><a href='/woocommerce/woocommerce-plugins/'><span>Plugin-uri <span class="badge badge-sidebar-primary"> 4 </span></span></a></li>
			  </ul>
		   </li>
		   <li class='has-sub'><a href='#'><span>XenForo</span></a>
			  <ul>
				 <li><a href='/xenforo/'><span>Totul pentru XenForo</span></a></li>
				 <li><a href='/xenforo/xenforo-releases/'><span>Versiuni XenForo <span class="badge badge-sidebar-primary"> 0 </span></span></a></li>
				 <li><a href='/xenforo/xenforo-skins/'><span>Stiluri / Șabloane <span class="badge badge-sidebar-primary"> 10 </span></span></a></li>
                 <li><a href='/xenforo/xenforo-mods/'><span>Moduri XenForo <span class="badge badge-sidebar-primary"> 14 </span></span></a></li>
			  </ul>
		   </li>
		   <li class='has-sub'><a href='#'><span>IPS Community Suite</span></a>
			  <ul>
				 <li><a href='/ips/'><span>Totul pentru IPS</span></a></li>
				 <li><a href='/ips/ips-download/'><span>Versiuni IPS <span class="badge badge-sidebar-primary"> 1 </span></span></a></li>
				 <li><a href='/ips/ips-skins/'><span>Șabloane IPS <span class="badge badge-sidebar-primary"> 19 </span></span></a></li>
                 <li><a href='/ips/moduri-ips/'><span>Moduri IPS <span class="badge badge-sidebar-primary"> 2 </span></span></a></li>
			  </ul>
		   </li>
		   <li class='has-sub'><a href='#'><span>Datalife Engine</span></a>
			  <ul>
				 <li><a href='/datalife-engine/'><span>Totul pentru DLE</span></a></li>
				 <li><a href='/datalife-engine/release-dle/'><span>Versiuni DLE <span class="badge badge-sidebar-primary"> 1 </span></span></a></li>
				 <li><a href='/datalife-engine/template-uri-dle/'><span>Teme / Șabloane <span class="badge badge-sidebar-primary"> 1 </span></span></a></li>
				 <li><a href='/datalife-engine/plugins-dle/'><span>Module / pluginuri <span class="badge badge-sidebar-primary"> 0 </span></span></a></li>
				 <li><a href='/datalife-engine/dle-tricks/'><span>Trucuri <span class="badge badge-sidebar-primary"> 0 </span></span></a></li>
			  </ul>
		   </li>
		   <li class='has-sub'><a href='#'><span>Șabloane HTML</span></a>
			  <ul>
				 <li><a href='/html-template/web-hosting/'><span>Web Hosting <span class="badge badge-sidebar-primary"> 12 </span></span></a></li>
				 <li><a href='/html-template/business-html/'><span>Business <span class="badge badge-sidebar-primary"> 15 </span></span></a></li>
				 <li><a href='/html-template/index-uri/'><span>Indexuri <span class="badge badge-sidebar-primary"> 18 </span></span></a></li>
				 <li><a href='/html-template/gaming-html/'><span>Gaming <span class="badge badge-sidebar-primary"> 5 </span></span></a></li>
				 <li><a href='/html-template/blog-html/'><span>Blog <span class="badge badge-sidebar-primary"> 6 </span></span></a></li>
				 <li><a href='/html-template/magazine-online/'><span>Magazine online <span class="badge badge-sidebar-primary"> 4 </span></span></a></li>
                 <li><a href='/html-template/landingpage-html/'><span>Landing Page <span class="badge badge-sidebar-primary"> 15 </span></span></a></li>
                 <li><a href='/html-template/pagini-404/'><span>Pagini 404 <span class="badge badge-sidebar-primary"> 0 </span></span></a></li>

			  </ul>
		   </li>
		   <li class='has-sub'><a href='#'><span>Surse PSD</span></a>
			  <ul>
				 <li><a href='/surse_psd/psd-bannere/'><span>Bannere</span><span class="badge badge-sidebar-primary"> 21 </span></a></li>
				 <li><a href='/surse_psd/psd-avatare/'><span>Avatare</span><span class="badge badge-sidebar-primary"> 11 </span></a></li>
				 <li><a href='/surse_psd/psd-logo/'><span>Logo-uri</span><span class="badge badge-sidebar-primary"> 0 </span></a></li>
				 <li><a href='/surse_psd/psd-semnaturi/'><span>Semnaturi</span><span class="badge badge-sidebar-primary"> 8 </span></a></li>
				 <li><a href='/surse_psd/youtube-banner/'><span>Bannere YouTube</span><span class="badge badge-sidebar-primary"> 0 </span></a></li>
				 <li><a href='/surse_psd/banner-twitch/'><span>Bannere Twitch</span><span class="badge badge-sidebar-primary"> 0 </span></a></li>
				 <li><a href='/surse_psd/preview-for-video/'><span>Previzualizare video</span><span class="badge badge-sidebar-primary"> 1 </span></a></li>

			  </ul>
		   </li>
		   <li><a href='/other-cms/'><span>Alte CMS, Scripturi PHP</span><span class="badge badge-sidebar-primary"> 18 </span></a></li>
		   <li><a href='/avatars/'><span>Avatare pentru forum </span></a></li>
		</ul>
	</div>
</ul>

    
<ul class="sidebar-nav">
<li class="sidebar-header">Altele</li>
	<div id='cssmenu'>
		<ul>
		   <li class='has-sub'><a href='#'><span>Partenerii artweber</span></a>
			  <ul>
				 <li><a href='https://ro.jooble.org/' target="_blank"><span>Jooble România</span></a></li>
                 <li><a href='https://cipriam.ro/' target="_blank"><span>Cipriam.Ro</span></a></li>
                 <li><a href='https://cybermouse.ro/' target="_blank"><span>CyberMouse.Ro</span></a></li>
                 <li><a href='https://forum.tesloianu.ro' target="_blank"><span>Tesloianu.Ro</span></a></li>
			  </ul>
		   </li>
		</ul>
	</div>
</ul>
    
</div>
</nav>
        
<div class="main">

<nav class="navbar navbar-expand navbar-light navbar-bg">

<a class="sidebar-toggle"><i class="hamburger align-self-center"></i></a>
    
<form method="post" class="d-none d-sm-inline-block">
<div class="input-group input-group-navbar">
<input type="hidden" name="do" value="search" />
<input type="hidden" name="subaction" value="search" />
<input type="text" class="form-control" name="story" placeholder="Cautare pe site …" aria-label="Cautare">
<div class="input-group-append"><button class="btn" type="submit"><i class="align-middle" data-feather="search"></i></button></div>
</div>
</form>

<div class="navbar-collapse collapse">
<ul class="navbar-nav navbar-align">



<li class="nav-item dropdown">
<a class="nav-link d-none d-sm-inline-block" data-toggle="modal" data-target="#defaultModalPrimary" href="#">
<span class="text-dark">Intra<i class="align-middle ml-1" data-feather="log-in"></i></span>
</a>
<a class="nav-link d-none d-sm-inline-block" href="https://artweber.ro/index.php?do=register">
<span class="text-dark"><i class="align-middle mr-1" data-feather="user-plus"></i>Inregistrare</span>
</a>
<div class="modal fade" id="defaultModalPrimary" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title">Autorizare</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
</div>
<div class="modal-body m-3">
<form name="login-form" id="loginform" method="post">
<div class="form-group">
<label for="user_login">Numele de profil</label>
<input type="text" name="login_name" id="login_name" value="">
</div>
<div class="form-group">
<label for="user_pass">Parola</label>
<input type="password" name="login_password" id="login_password">
</div>
<div class="form-group">
<input type="submit" class="bbcodes" style="width:100%" value="Войти">
<input name="login" type="hidden" id="login" value="submit">
</div>
<div class="row"><div class="col-md-12">
<div class="float-right"><a href="https://artweber.ro/index.php?do=register">Inregistrare pe site</a></div>
<div class="float-left"><a href="https://artweber.ro/index.php?do=lostpassword">Recuperarea parolei</a></div>
</div></div>
</form>
</div>
</div></div></div>
</li>

</ul>
</div>
</nav>

<nav aria-label="breadcrumb"><div class="breadcrumb"><div class="speedbar"><div class="over"><span itemscope itemtype="https://schema.org/BreadcrumbList"><span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"><meta itemprop="position" content="1"><a href="https://artweber.ro/" itemprop="item"><span itemprop="name">Pagina principala</span></a></span></span></div></div></div></nav>
   
<main class="content">
<div class="container-fluid p-0">











<div class="row">
<div id='dle-content'></div><div class="col-lg-12">
<div class="alert alert-danger alert-outline-coloured alert-dismissible" role="alert">
<div class="alert-icon"><i class="align-middle" data-feather="bell"></i></div>
<div class="alert-message">
<strong>Warning! An error was detected!</strong> Sorry, the page 404.html is not available for you: its address could have changed or it has been removed. Please use the search.
</div>
</div></div>
</div>

<div class="card mt-4">
<div class="card-header pb-0"><h5 class="card-title mb-0">Comentarii noi</h5></div>
<div class="card-body p-3">
<div id="tasks-upcoming"><div class="row">

</div></div>
<a href="/index.php?do=lastcomments" class="btn btn-outline-primary btn-block">Toate comentariile</a>
</div></div>

<div class="row mt-4">

<div class="col-12 col-lg-6 col-xl-4">
<script>
<!--
function doVote( event ){

	
	var vote_check = $('#dle-vote input:radio[name=vote_check]:checked').val();
	
	if (typeof vote_check == "undefined" &&  event == "vote") {
		return false;
	}
	
	ShowLoading('');

	$.get(dle_root + "engine/ajax/controller.php?mod=vote", { vote_id: "1", vote_action: event, vote_check: vote_check, vote_skin: dle_skin, user_hash: dle_login_hash }, function(data){

		HideLoading('');

		$("#vote-layer").fadeOut(500, function() {
			$(this).html(data);
			$(this).fadeIn(500);
		});

	});
}
//-->
</script><div id='vote-layer'><div class="card">
<div class="card-header pb-0"><h5 class="card-title mb-0">Ce resurse doriti mai multe?</h5></div>
<div class="card-body p-3">

<form method="post" name="vote">


<div class="vote_list"><div id="dle-vote"><div class="vote"><input id="vote_check0" name="vote_check" type="radio" value="0" /><label for="vote_check0"> WordPress</label></div><div class="vote"><input id="vote_check1" name="vote_check" type="radio" value="1" /><label for="vote_check1"> WooCommerce</label></div><div class="vote"><input id="vote_check2" name="vote_check" type="radio" value="2" /><label for="vote_check2"> Datalife Engine</label></div><div class="vote"><input id="vote_check3" name="vote_check" type="radio" value="3" /><label for="vote_check3"> Șabloane HTML</label></div><div class="vote"><input id="vote_check4" name="vote_check" type="radio" value="4" /><label for="vote_check4"> Scripturi</label></div></div></div>




<input type="hidden" name="vote_action" value="vote">
<input type="hidden" name="vote_id" id="vote_id" value="1">
<button class="btn btn-primary btn-block" type="button" onclick="doVote('vote'); return false;">Votează</button>
<button class="btn btn-outline-primary btn-block" type="button" onclick="doVote('results'); return false;">Rezultatele</button>
</form>

</div>
</div></div>
</div>
    
<div class="col-12 col-lg-6 col-xl-4">
<div class="card">
<div class="card-header pb-0"><h5 class="card-title mb-0">Calendarul</h5></div>
<div class="card-body p-3"><div id="calendar-layer"><table id="calendar" class="calendar"><tr><th colspan="7" class="monthselect"><a class="monthlink" onclick="doCalendar('12','2021','right'); return false;" href="https://artweber.ro/2021/12/" title="Previous month">&laquo;</a>&nbsp;&nbsp;&nbsp;&nbsp;January 2022&nbsp;&nbsp;&nbsp;&nbsp;&raquo;</th></tr><tr><th class="workday">Mon</th><th class="workday">Tue</th><th class="workday">Wed</th><th class="workday">Thu</th><th class="workday">Fri</th><th class="weekday">Sat</th><th class="weekday">Sun</th></tr><tr><td colspan="5">&nbsp;</td><td  class="day-active" ><a class="day-active" href="https://artweber.ro/2022/01/01/" title="Al posts for 01 January 2022">1</a></td><td  class="weekday" >2</td></tr><tr><td  class="day" >3</td><td  class="day" >4</td><td  class="day" >5</td><td  class="day" >6</td><td  class="day" >7</td><td  class="weekday day-current" >8</td><td  class="weekday" >9</td></tr><tr><td  class="day" >10</td><td  class="day" >11</td><td  class="day" >12</td><td  class="day" >13</td><td  class="day" >14</td><td  class="weekday" >15</td><td  class="weekday" >16</td></tr><tr><td  class="day" >17</td><td  class="day" >18</td><td  class="day" >19</td><td  class="day" >20</td><td  class="day" >21</td><td  class="weekday" >22</td><td  class="weekday" >23</td></tr><tr><td  class="day" >24</td><td  class="day" >25</td><td  class="day" >26</td><td  class="day" >27</td><td  class="day" >28</td><td  class="weekday" >29</td><td  class="weekday" >30</td></tr><tr><td  class="day" >31</td><td colspan="6">&nbsp;</td></tr></table></div></div>
</div>
</div>
    
<div class="col-12 col-lg-6 col-xl-4">
<div class="card">
<div class="card-header pb-0"><h5 class="card-title mb-0">Nor de etichete</h5></div>
<div class="card-body p-3">
<div class="tagssp"><span class="clouds_xsmall"><a href="https://artweber.ro/tags/ADMIN%20PANEL/" title="Publication found: 5">ADMIN PANEL</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/Admin%20Template/" title="Publication found: 4">Admin Template</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/AJAX/" title="Publication found: 2">AJAX</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/Blog/" title="Publication found: 3">Blog</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/Bootstrap/" title="Publication found: 9">Bootstrap</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/Business/" title="Publication found: 3">Business</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/Counter-Strike/" title="Publication found: 3">Counter-Strike</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/Creative/" title="Publication found: 2">Creative</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/CSGO/" title="Publication found: 2">CSGO</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/DARK%20STYLE/" title="Publication found: 8">DARK STYLE</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/Dashboard/" title="Publication found: 4">Dashboard</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/eCommerce/" title="Publication found: 2">eCommerce</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/Elementor/" title="Publication found: 5">Elementor</a></span> <span class="clouds_small"><a href="https://artweber.ro/tags/ELEMENTOR/" title="Publication found: 12">ELEMENTOR</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/game/" title="Publication found: 3">game</a></span> <span class="clouds_small"><a href="https://artweber.ro/tags/Gaming/" title="Publication found: 15">Gaming</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/GTA/" title="Publication found: 2">GTA</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/GTA%205/" title="Publication found: 3">GTA 5</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/Hosting/" title="Publication found: 6">Hosting</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/hosting%20template/" title="Publication found: 5">hosting template</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/HTML/" title="Publication found: 10">HTML</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/HTML5/" title="Publication found: 3">HTML5</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/Landing%20Page/" title="Publication found: 11">Landing Page</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/MARKETING/" title="Publication found: 2">MARKETING</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/Marketing/" title="Publication found: 3">Marketing</a></span> <span class="clouds_xlarge"><a href="https://artweber.ro/tags/NULLED/" title="Publication found: 40">NULLED</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/Personal/" title="Publication found: 2">Personal</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/Portfolio/" title="Publication found: 3">Portfolio</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/Portofoliu/" title="Publication found: 2">Portofoliu</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/Premium/" title="Publication found: 7">Premium</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/Responsive/" title="Publication found: 5">Responsive</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/RolePlay/" title="Publication found: 8">RolePlay</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/RUS/" title="Publication found: 2">RUS</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/SAMP/" title="Publication found: 5">SAMP</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/SEO/" title="Publication found: 2">SEO</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/Shop/" title="Publication found: 2">Shop</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/Template/" title="Publication found: 4">Template</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/universal/" title="Publication found: 2">universal</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/web%20hosting/" title="Publication found: 3">web hosting</a></span> <span class="clouds_xsmall"><a href="https://artweber.ro/tags/WHMCS/" title="Publication found: 9">WHMCS</a></span><div class="tags_more"><a href="https://artweber.ro/tags/">Show all tags</a></div></div>
</div></div>
</div>
    
</div>

</div>
</main>

<footer class="footer">
<div class="container-fluid">
<div class="row text-muted">

<div class="col-6 text-left">
<ul class="list-inline">
<li class="list-inline-item"><a class="text-muted" href="#">Reguli</a></li>
<li class="list-inline-item"><a class="text-muted" href="#">Statistici</a></li>
<li class="list-inline-item"><a class="text-muted" href="#">Feedback</a></li>
<li class="list-inline-item"><a class="text-muted" href="#">Confidențialitate</a></li>
</ul>
</div>

<div class="col-6 text-right">

<!-- Yandex.Metrika informer -->
<a href="https://metrika.yandex.com/stat/?id=54882298&amp;from=informer"
target="_blank" rel="nofollow"><img src="https://informer.yandex.ru/informer/54882298/3_1_FFFFFFFF_EFEFEFFF_0_pageviews"
style="width:88px; height:31px; border:0;" alt="Яндекс.Метрика" title="Яндекс.Метрика: данные за сегодня (просмотры, визиты и уникальные посетители)" class="ym-advanced-informer" data-cid="54882298" data-lang="ru" /></a>
<!-- /Yandex.Metrika informer -->

<p class="mb-0">© Copyright &copy; 2021. <a href="https://artweber.ro/" class="text-muted" target="_blank">ARTWEBER.RO</a> - All Rights Reserved.</p>

</div>

</div></div>
</footer>
            
</div></div>

<link href="/engine/editor/css/default.css?v=68cdc" rel="stylesheet" type="text/css">
<script src="/engine/classes/js/jquery3.js?v=68cdc"></script>
<script src="/engine/classes/js/jqueryui3.js?v=68cdc" defer></script>
<script src="/engine/classes/js/dle_js.js?v=68cdc" defer></script>
<script>
<!--
var dle_root       = '/';
var dle_admin      = '';
var dle_login_hash = '1e0ce170c158485bf9bee3e45ae9fbe3216e70a6';
var dle_group      = 5;
var dle_skin       = 'BOOTBLOG';
var dle_wysiwyg    = '2';
var quick_wysiwyg  = '1';
var dle_min_search = '4';
var dle_act_lang   = ["Yes", "No", "Enter", "Cancel", "Save", "Delete", "Loading. Please, wait..."];
var menu_short     = 'Quick edit';
var menu_full      = 'Full edit';
var menu_profile   = 'View profile';
var menu_send      = 'Send message';
var menu_uedit     = 'Admin Center';
var dle_info       = 'Information';
var dle_confirm    = 'Confirm';
var dle_prompt     = 'Enter the information';
var dle_req_field  = 'Please fill in all the required fields';
var dle_del_agree  = 'Are you sure you want to delete it? This action cannot be undone';
var dle_spam_agree = 'Are you sure you want to mark the user as a spammer? This will remove all his comments';
var dle_c_title    = 'Send a complaint';
var dle_complaint  = 'Enter the text of your complaint to the Administration:';
var dle_mail       = 'Your e-mail:';
var dle_big_text   = 'Highlighted section of text is too large.';
var dle_orfo_title = 'Enter a comment to the detected error on the page for Administration ';
var dle_p_send     = 'Send';
var dle_p_send_ok  = 'Notification has been sent successfully ';
var dle_save_ok    = 'Changes are saved successfully. Refresh the page?';
var dle_reply_title= 'Reply to the comment';
var dle_tree_comm  = '0';
var dle_del_news   = 'Delete article';
var dle_sub_agree  = 'Do you really want to subscribe to this article’s comments?';
var dle_captcha_type  = '0';
var DLEPlayerLang     = {prev: 'Previous',next: 'Next',play: 'Play',pause: 'Pause',mute: 'Mute', unmute: 'Unmute', settings: 'Settings', enterFullscreen: 'Enable full screen mode', exitFullscreen: 'Disable full screen mode', speed: 'Speed', normal: 'Normal', quality: 'Quality', pip: 'PiP mode'};
var allow_dle_delete_news   = false;
var dle_search_delay   = false;
var dle_search_value   = '';
jQuery(function($){
FastSearch();
});
//-->
</script>
<script src="/templates/BOOTBLOG/js/app.js"></script>

    
</body>
</html>
<!-- DataLife Engine Copyright SoftNews Media Group (http://dle-news.ru) -->
